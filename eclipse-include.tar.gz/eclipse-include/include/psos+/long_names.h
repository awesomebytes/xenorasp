#ifndef LONG_NAMES_H
#define LONG_NAMES_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

const char *__psos_maybe_short_name(char shrt[5], const char *lng);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* LONG_NAMES_H */
