#ifdef __i386__
#include "features_32.h"
#else
#include "features_64.h"
#endif
