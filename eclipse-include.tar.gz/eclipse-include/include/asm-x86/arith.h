#ifdef __i386__
#include "arith_32.h"
#else
#include "arith_64.h"
#endif
