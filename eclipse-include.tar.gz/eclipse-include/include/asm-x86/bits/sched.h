#ifdef __i386__
#include "sched_32.h"
#else
#include "sched_64.h"
#endif
