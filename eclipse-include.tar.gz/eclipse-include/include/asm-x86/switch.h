#ifdef __i386__
#include "switch_32.h"
#else
#include "switch_64.h"
#endif
