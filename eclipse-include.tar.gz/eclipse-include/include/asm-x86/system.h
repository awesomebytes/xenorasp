#ifdef __i386__
#include "system_32.h"
#else
#include "system_64.h"
#endif
